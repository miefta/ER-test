<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

if ( ! function_exists( 'anti_injection' ) ) {
	function anti_injection( $data ){
		$filter = stripslashes( strip_tags( htmlspecialchars( $data, ENT_QUOTES ) ) );
		return $filter;
	}
}

if ( ! function_exists( 'encyript_password' ) ) {
	function encyript_password( $password ) {
		$salt = '!@#$%^&*()<>?:9876543210ABCDEFG';
		return md5( $password.md5( $password.$salt ) );
	}
}


if ( ! function_exists( 'limitChar' ) ) {
	function limitChar( $content, $limit ) {
	    if ( strlen( $content ) <= $limit ) {
	        return $content;
	    } else {
	        $excerpt = substr( $content, 0, $limit );
	        return $excerpt.'...';
	    }
	}
}

if ( ! function_exists( 'limitWord' ) ) {
	function limitWord( $string, $word_limit ) {
	   $words = explode( " ", $string );
	   return implode( " ", array_splice( $words, 0, $word_limit ) );
	}
}

if(! function_exists('rupiah')){
	function rupiah($nilai){
	   if($nilai==''){
	   	  $nilai = 0;
	   }
	   $rupiah = number_format($nilai, 0, ',', '.');
	   return $rupiah;
	}
}

if(! function_exists('rupiah_to_number')){
	function rupiah_to_number($rupiah){
	   return intval(preg_replace("/[^0-9]/", "", $rupiah));
	}
}

if ( ! function_exists('my_slug')){
	function my_slug( $string ) {
		$string_lowercase = strtolower( $string );
		$filter = str_replace( array( ' ', '.', ',', ':', '/', '*', '^', '%', '$', '#', '(', ')', '_', "'", '"','&' ), '-', $string_lowercase );
		$max_dash = 1;
		$val_find = '-';
		$val_replace = '';

		while ( $max_dash > 0 ) {
			$val_find = $val_find . '-';
			$val_replace = $val_replace . '-';
			$max_dash--;
		}

		while ( strrpos( $filter, $val_find ) !== false ) {
			 $filter = str_replace( $val_find, $val_replace, $filter );
		}
		return $filter;
	}
}
