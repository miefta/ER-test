<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MY_Controller extends CI_Controller{
  function render_page($content, $data = NULL){
	    /*
	     * $data['headernya'] , $data['contentnya'] , $data['footernya']
	     * variabel diatas ^ nantinya akan dikirim ke file views/template/index.php
	     * */
	    
	    date_default_timezone_set('Asia/Jakarta');
        $data['template'] = $this->load->view('template', $data, TRUE);
        $data['content']  = $this->load->view($content, $data, TRUE);
        
        $this->load->view('template', $data);

    }
}
?>