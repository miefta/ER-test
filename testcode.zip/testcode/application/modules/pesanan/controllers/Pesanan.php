<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesanan extends MY_Controller {

	function __construct(){
    parent::__construct();
    	$this->load->library('cart');
	   	$this->load->model('m_pesanan');
  	}

	public function index(){
		$user  = $this->session->userdata('admin_id');
		$akses = $this->session->userdata('admin_access');
		if($akses == 100){
			$where = array(
				'user' => $user
				);
		}else{
			$where = array();
		}

		$data['pesanan'] = $this->m_pesanan->list_pesanan($where);

		$this->render_page('daftar_pesanan', $data);
	}

	public function buat_pesanan(){
		$akses = $this->session->userdata('admin_access');
		if($akses == 100){
		$data['makanan'] = $this->m_pesanan->daftar_menu('makanan');
		$data['minuman'] = $this->m_pesanan->daftar_menu('minuman');
		$data['no_pesanan'] = $this->m_pesanan->no_pesanan();
		$this->render_page('buat_pesanan', $data);
		}else{
			echo "<script>alert('akun anda tidak memiliki akses ke halaman ini');document.location.href='".base_url("pesanan")."';</script>";
		}
	}

	public function edit_pesanan($nopesanan = null){
		if($nopesanan != null){
		$data['makanan'] = $this->m_pesanan->daftar_menu('makanan');
		$data['minuman'] = $this->m_pesanan->daftar_menu('minuman');
		$data['no_pesanan'] = $nopesanan;
		$where  = array('no_pesanan'=>$nopesanan);
		$data['datapesan'] = $this->m_pesanan->list_pesanan_list($where);
		$check = $this->m_pesanan->list_pesanan($where);
			if($check->num_rows() > 0){
				$data['data_det'] = $check->row();
				$this->render_page('edit_pesanan', $data);
			}else{
				show_404();
			}
		}else{
			show_404();
		}
	}

	function edit_orderdb_tambah($orderid){
		if($this->input->is_ajax_request() && $orderid != null){
			$itemid = $this->input->post('item');
			$where  = array('id_menu' => $itemid, 'status' => 'ready');
			$where1 = array('no_pesanan'=>$orderid);
			$check  = $this->m_pesanan->check_list($where, 'menu');
			$check1 = $this->m_pesanan->list_pesanan($where1);
			if($check->num_rows() > 0 && $check1->num_rows() > 0){
			
				$menu    = $check->row();
				$pesanan = array(
					'no_pesanan' => $orderid,
					'id_menu'    => $menu->id_menu,
					'qty'        => 1,
					'harga'      => $menu->harga,
					'total'      => $menu->harga
				);
				$insertcart = $this->db->insert('pesanan_list', $pesanan);
				if($insertcart){
					$json['status']  = 11;
					
				}else{
					$json['status']  = '01';
					$json['alert']   = 'alert-danger';
					$json['message'] = 'Error -1';
				}
			}else{
				$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Menu tidak tersedia';
			}
			echo json_encode($json);
		}else{
			show_404();
		}
	}

	function delete_orderdb($orderid){
		if($this->input->is_ajax_request() && $orderid != null){
			$id     = $this->input->post('item');
			$where1 = array('no_pesanan'=>$orderid);
			$check1 = $this->m_pesanan->list_pesanan($where1);
			if($check1->num_rows() > 0){
				$hap    = array('id_list'=> $id, 'no_pesanan' => $orderid);
				$delete = $this->db->delete('pesanan_list', $hap); 
				if($delete){
					$json['status']  = 11;
				}else{
					$json['status']  = '01';
					$json['alert']   = 'alert-danger';
					$json['message'] = 'Gagal Hapus data';
				}
			}else{
				$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Data tidak ada';
			}
			echo json_encode($json);
		}else{
			show_404();
		}
	}

	function update_orderdb($orderid){
		if($this->input->is_ajax_request() && $orderid != null){
		$rowid  = $this->input->post('item');
		$qty    = $this->input->post('qty');

		$where  = array('id_list'=> $rowid, 'no_pesanan' => $orderid);
		$order  = $this->m_pesanan->list_pesanan_list($where)->row();

		$data= array(
	        'no_pesanan' => $orderid,
	        'qty'	  => $qty,
	        'total'   => $qty*$order->harga
    	);
    	$update = $this->db->update('pesanan_list', $data, array('id_list' => $rowid));
    		if($update){
    			$json['status']  = 11;
    		}else{
    			$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Gagal update order';
    		}
    		echo json_encode($json);
		}else{
			show_404();
		}
	}

	function initorder(){
		if($this->input->is_ajax_request()){
			$itemid         = $this->input->post('item');
			$where          = array('id_menu' => $itemid, 'status' => 'ready');
			$check          = $this->m_pesanan->check_list($where, 'menu');
			if($check->num_rows() > 0){
				$menu    = $check->row();
				$pesanan = array(
					'id'    => $menu->id_menu,
					'qty'   => 1,
					'name'  => $menu->nama_menu,
					'price' => $menu->harga
				);
				$insertcart = $this->cart->insert($pesanan);
				if($insertcart){
					$json['status']  = 11;
					
				}else{
					$json['status']  = '01';
					$json['alert']   = 'alert-danger';
					$json['message'] = 'Error -1';
				}
			}else{
				$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Menu tidak tersedia';
			}
			echo json_encode($json);
		}else{
			show_404();
		}
	}

	function order_list($segment = null){
		if($segment == 'total_order'){
			$order['total'] = $this->cart->total();
		}else{
			$order = array();
			foreach ($this->cart->contents() as $items) {
				$order[] = $items;
			}
		}
		echo json_encode($order);
	}

	function update_order(){
		if($this->input->is_ajax_request()){
		$rowid  = $this->input->post('item');
		$qty    = $this->input->post('qty');
		$data= array(
	        'rowid' => $rowid,
	        'qty'	=> $qty
    	);
    	$update = $this->cart->update($data);
    		if($update){
    			$json['status']  = 11;
    		}else{
    			$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Gagal update order';
    		}
    		echo json_encode($json);
		}else{
			show_404();
		}
	}

	function delete_order(){
		if($this->input->is_ajax_request()){
		$rowid  = $this->input->post('item');
		$data   = array('rowid' => $rowid, 'qty' => 0 );
		$delete = $this->cart->update($data);
			if($delete){
				$json['status']  = 11;
			}else{
				$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Gagal hapus order';
			}
			echo json_encode($json);
		}else{
			show_404();
		}
	}

	function prosesorder(){
		if($this->input->is_ajax_request()){
			$total      = $this->cart->total();
			$nomeja     = $this->input->post('meja');
			$order      = array();
			if($total > 0){
			foreach ($this->cart->contents() as $items) {
				$order[] = array(
					'no_pesanan' => $this->m_pesanan->no_pesanan(),
					'id_menu'    => $items['id'],
					'qty'        => $items['qty'],
					'harga'      => $items['price'],
					'total'      => $items['qty']*$items['price']
					);
			}
			$detailorder = array(
				'no_pesanan'=> $this->m_pesanan->no_pesanan(),
				'no_meja'   => $nomeja,
				'tanggal'   => date('Y-m-d H:i:s'),
				'total'     => $total,
				'user'      => $this->session->userdata('admin_id'),
				'status'	=> 'aktif',
				);
			$activity = array(
				'id_user'  => $this->session->userdata('admin_id'),
				'activity' => 'Buat Pesanan No.'.$this->m_pesanan->no_pesanan()
				);
			$insert = $this->m_pesanan->buat_pesanan('pesanan_list', 'pesanan', $order, $detailorder);
				if($insert){
					$json['status'] 	= 11;
					$json['alert']   	= 'alert-success';
					$json['message'] 	= 'Pesanan akan diproses';
					$json['no_pesanan'] = $this->m_pesanan->no_pesanan();
					$this->cart->destroy();
					$this->m_pesanan->record_activity($activity);
				}else{
					$json['status']  = '01';
					$json['alert']   = 'alert-danger';
					$json['message'] = 'Error -1';
				}
			}else{
				$json['status']  = '01';
				$json['alert']   = 'alert-danger';
				$json['message'] = 'Pesanan Kosong';
			}
		echo json_encode($json);
		}else{
			show_404();
		}
	}

}
