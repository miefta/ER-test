<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_pesanan extends CI_Model{

	function no_pesanan(){
		$this->db->select('*, LEFT(no_pesanan,3) as kode', FALSE);
		$this->db->order_by('no_pesanan','DESC');    
		$this->db->limit(1);     
		$query = $this->db->get('pesanan');    
		if($query->num_rows() <> 0){       
		   $data = $query->row(); 
		   $subs = substr($data->no_pesanan, -3);     
		   $kode = intval($subs) + 1;   
		}
		else{       
		   $kode = 1;  
		}
		$kodemax  = str_pad($kode, 3, "0", STR_PAD_LEFT);    
		$kodejadi = 'ERP'.date('dmY').'-'.$kodemax; 

		return $kodejadi;  
	}

	function list_pesanan($where = null){
		$this->db->from('pesanan');
		if($where != null){
			$this->db->where($where);
		}
		return $this->db->get();
	}

	function list_pesanan_list($where){
		$this->db->select('*');
		$this->db->from('pesanan_list');
		$this->db->join('menu', 'pesanan_list.id_menu=menu.id_menu');
		$this->db->where($where);
		$this->db->order_by('pesanan_list.id_list', 'ASC');
		return $this->db->get();
	}

	function daftar_menu($menu){
		$this->db->where('kategori', $menu);
		return $this->db->get('menu');
	}

	function check_list($where, $db){
		$this->db->where($where);
		return $this->db->get($db);
	}

	function buat_pesanan($db, $db2, $order, $detailorder){
		$insert  = $this->db->insert($db2, $detailorder);
		$insertb = $this->db->insert_batch($db, $order); 
		if($insert && $insertb){
			return true;
		}else{
			return false;
		}
	}

	function record_activity($data){
		$record      = array(
				'id_adm'       => $data['id_user'],
				'activity'     => $data['activity'],
				'record'       => date('Y-m-d H:i:s')
				);
		$this->db->insert('record_activity', $record);
	}
}