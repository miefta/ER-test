<!-- DataTables -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.css">

<section class="content-header">
<h1>Daftar Pesanan</h1>
</section>

<section class="content">
    <div class="row">
    <div class="col-sm-12">
		 <div class="box box-default">
            <div class="box-header with-border text-right">
              <a href="<?php echo base_url('pesanan/buat_pesanan') ?>" class="btn btn-success">Buat Pesanan Baru</a>
            </div>
            <div class="box-body">
              
             <table id="table01" class="table table-bordered table-striped">
             	<thead>
             		<tr>
             			<th>No. Pesanan</th>
             			<th>No. Meja</th>
             			<th>Waktu</th>
             			<th>Status</th>
                        <th class="text-right">Action</th>
             		</tr>
             	</thead>
             	<tbody>
             	<?php foreach ($pesanan->result() as $key) { 
                    if($key->status == 'aktif'){ $st = base_url('pesanan/edit_pesanan/').$key->no_pesanan; $ds = ''; }else{ $st = '#'; $ds = 'disable'; }
                    ?>
             		<tr>
             			<td><?php echo $key->no_pesanan ?></td>
             			<td><?php echo $key->no_meja ?></td>
             			<td><?php echo date('d-m-Y H:i:s'. strtotime($key->tanggal)) ?></td>
             			<td><?php echo $key->status ?></td>
                        <td style="text-align: right"><a href="<?php echo $st ?>" <?php echo $ds ?> class="btn btn-success">Edit Pesanan</a></td>
             		</tr>
             	<?php } ?>
             	</tbody>
             </table>
              
              
            </div>
          </div>
    </div>
    </div>
</section>

<!-- DataTables -->
<script src="<?php echo base_url().'assets/' ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url().'assets/' ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.4.0/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.4.0/js/buttons.flash.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
<script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script>
<script src="//cdn.datatables.net/buttons/1.4.0/js/buttons.html5.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.4.0/js/buttons.print.min.js"></script>
<script type="text/javascript">
$('#table01').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'excel'
        ]
    });
</script>