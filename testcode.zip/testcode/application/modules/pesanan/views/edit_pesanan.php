<section class="content-header">
<h1>Edit Pesanan No. <?php echo $no_pesanan ?> 
<a href="<?php echo base_url('pesanan') ?>" class="pull-right btn btn-success">Daftar Pesanan</a></h1>
</section>

<section class="content">
    <div class="row">
    <div class="col-sm-12">
    <div class="box box-default">
    <div class="box-body">
    <div class="row">
      <div class="col-sm-4">
          <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                <input type="text" class="form-control" value="<?php echo $data_det->tanggal  ?>" readonly>
            </div>
            </div>
            <div class="col-sm-4">
          <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-list" aria-hidden="true"></i></span>
                <input id="ordernumber" type="text" class="form-control" value="<?php echo $no_pesanan ?>" readonly>
            </div>
            </div>
            <div class="col-sm-4">
          	<div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" value="<?php echo $this->session->userdata('admin_name'); ?>" readonly>
              </div>
            </div>            
        </div>
    </div>
    </div>
    </div>


    <div class="col-sm-6">
    <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true">Makanan</a></li>
              <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="false">Minuman</a></li>
              
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                <div class="row row-mar">
                <?php 
                foreach ($makanan->result() as $key) {
                ?>
                <div class="col-sm-3 col-pad">
                <div class="box-produk" data-item="<?php echo $key->id_menu ?>">
                <div class="img">
                <img class="img-responsive" src="<?php echo base_url('assets/img/').$key->image ?>">
                <?php 
                if($key->status == 'empty'){
                    echo '<div class="sold">HABIS</div>';
                  }
                ?>
                </div>
                <div class="text-center">
                    <p><strong><?php echo $key->nama_menu ?></strong></p>
                    <span><?php echo 'IDR '.rupiah($key->harga) ?></span>
                </div>
                </div>
                </div>
                <?php } ?>
                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
              <div class="row row-mar">
                <?php 
                foreach ($minuman->result() as $key) {
                ?>
                <div class="col-sm-3 col-pad">
                <div class="box-produk">
                <img class="img-responsive" src="<?php echo base_url('assets/img/').$key->image ?>">
                <div class="text-center">
                    <p><strong><?php echo $key->nama_menu ?></strong></p>
                    <span><?php echo 'IDR '.rupiah($key->harga) ?></span>
                </div>
                </div>
                </div>
                <?php } ?>
                </div>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
    </div>

    <div class="col-sm-6">
    
    <form id="form-pemesanan" action="<?php echo base_url('pesanan/prosesorder'); ?>" method="post"> 
    <div class="box box-default">
        <div class="box-header with-border row">
            <div class="col-sm-6 text-right">
                <label style="margin-top: 5px;">No. Meja</label>
            </div>
            <div class="col-sm-6">
                <select name="meja" class="form-control pull-right">
                    <?php for ($i=1; $i < 11; $i++) { 
                        if($data_det->no_meja == $i) { $ch = 'checked'; }else{ $ch = ''; }
                    ?>
                    <option value="<?php echo $i; ?>" <?php echo $ch ?>><?php echo $i; ?></option>
                    <?php } ?>
                  </select>
            </div>
              
              
        </div>
    <div class="box-body  scrollable scr-min">
      <table class="table table-pos">
            <thead>
                <tr>
                    <th>Menu</th>
                    <th>Qty</th>
                    <th class="text-right">Harga</th>
                    <th class="text-right">Total</th>
                </tr>
            </thead>
            <tbody>           
            <?php 
            $total = 0;
            foreach ($datapesan->result() as $key) {
                $total = $total+$key->total;
               ?>
               <tr>
               <td><a href="#" class="del-order" data-id="<?php echo $key->id_list ?>"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;<input type="hidden" name="id_menu[]" value=""><?php echo $key->nama_menu ?></td>
               <td><input type="number" class="upd-qty" min="1" name="qty[]" value="<?php echo $key->qty ?>"></td>
               <td><?php echo $key->harga ?></td>
               <td><?php echo $key->total ?></td></tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
    

    
    <div class="box-body">
    <div class="transaction-menu">
            <div class="row">
            <div class="col-sm-12 ">
            <div class="bts-pr"></div>
            <table id="total-amount-due">
              <tbody><tr>
                <td>TOTAL AMOUNT</td>
                <td>
                  <input style="font-weight: 600; font-size: 20px" type="text" class="form-control total-amount-due priceformat text-right" value="<?php echo $total ?>" readonly="">
                </td>
              </tr>
            </tbody></table>
            </div>
        </div>
        </div>
    </div>
    </div>

    <ul class="pos-payment">
            <li>
            <a href="<?php echo base_url('pesanan') ?>" class="btn btn-block btn-lg btn-success xxcfgh"><b>Finish</b></a>
            </li>
            <div class="clearfix"></div>
    </ul>
    </form>

    </div>

    </div>
</section>

<script type="text/javascript">
function initOrder(item){
    $.ajax({
        url: "<?php echo base_url('pesanan/edit_orderdb_tambah/').$no_pesanan ?>",
        type: "POST",
        data:'item=' + item,
        dataType:'json',
        success: function(data){
            alert_notifications(data.alert, data.message);
            if(data.status == 11){
               location.reload();
            }
        }
    });
}

function initDelete(item){
    $.ajax({
        url: "<?php echo base_url('pesanan/delete_orderdb/').$no_pesanan ?>",
        type: "POST",
        data:'item=' + item,
        dataType:'json',
        success: function(data){
            alert_notifications(data.alert, data.message);
            if(data.status == 11){
               location.reload();
            }
        }
    });
}

function initUpdate(item, qty){
    $.ajax({
        url: "<?php echo base_url('pesanan/update_orderdb/').$no_pesanan ?>",
        type: "POST",
        data: {item:item, qty:qty},
        dataType:'json',
        success: function(data){
            alert_notifications(data.alert, data.message);
            if(data.status == 11){
                location.reload();
            }
        }
    });
}

$(function(){

$('.box-produk').on('click', function(){
    var item = $(this).data('item');
    initOrder(item);
});

$('body').on('click', '.del-order', function(){
    var item = $(this).data('id');
    initDelete(item);
});

$('body').on('change', '.upd-qty', function(){
    var item = $(this).closest('tr').find('a').data('id'),
        qty  = $(this).val();
    initUpdate(item, qty);
});

});
</script>
