<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct(){
    parent::__construct();
	   	$this->load->model('m_access');
  	}

	public function index(){
		if($this->session->userdata('admin_login') == true){
			if($this->session->userdata('admin_access') == 100){
				redirect(base_url('menu'));
			}else{
				redirect(base_url('kasir'));
			}
		}else{
		$this->load->view('mainpage');
		}
	}

	function access(){
		if($this->input->post('field_001') && $this->input->post('field_002')){
			$email = anti_injection($this->input->post('field_001'));
			$passw = encyript_password(anti_injection($this->input->post('field_002')));

			$login = $this->m_access->access($email, $passw);
			if($login){
				$login_sess = array(
					'admin_id'     => $login->id_adm,
					'admin_name'   => $login->nama,
					'admin_access' => $login->akses,
					'admin_login'  => true
					);
				$this->session->set_userdata($login_sess);
				$json['status']   = 11;
				$json['user']     = $login_sess;
			}else{
				$json['status']   = 10;
				$json['alert']    = 'alert-warning';
				$json['messsage'] = 'Email atau Password tidak sesuai.';
			}
			echo json_encode($json);
		}else{
			show_404();
		}
	}

	function logout(){
		if($this->session->userdata('admin_login') == true){
			$data = array(
				'id_user'  => $this->session->userdata('admin_id'),
				'activity' => 'logout'
				);
			$this->m_access->record_activity($data);
			$this->session->sess_destroy();
			redirect(base_url());
		}else{
			show_404();
		}
	}
}
