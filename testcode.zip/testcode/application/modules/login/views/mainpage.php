<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Test Code | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/font-awesome.min.css') ?>">
  
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('assets/custom/css/AdminLTE.min.css') ?>">
  <!-- Custom style -->
  <link rel="stylesheet" href="<?php echo base_url('assets/custom/css/custom.css') ?>">
  

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<style type="text/css">
html, body {
    height: auto;
}
</style>
<body class="hold-transition login-page">
<div class="alert_notifications show">
	
</div>
<div class="login-box">
  <div class="login-logo">
    <b>Login</b>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>
    <form id="form-login" action="<?php echo base_url('login/access'); ?>" method="post">
      <div class="form-group has-feedback">
        <input type="email" name="field_001" class="form-control" placeholder="Email" autocomplete="off" required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" name="field_002" class="form-control" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <!-- /.col -->
        <div class="col-xs-12">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/validate/jquery.validate.js') ?>"></script>

<script src="<?php echo base_url('assets/custom/js/custom.js') ?>"></script>
<script type="text/javascript">
$(function(){
	$('#form-login').validate({
		errorPlacement: function(error, element) {
   		},
   		submitHandler: function(form) {
   		$.ajax({
	        url: form.action,
            type: form.method,
            data: $(form).serialize(),
      		dataType: 'json',
	        success: function(data){
	        	alert_notifications(data.alert, data.messsage);
	        	if(data.status == 11){
	        		location.reload();
	        	}
	        }
    	});
   		}
	});
});
</script>
</body>
</html>
