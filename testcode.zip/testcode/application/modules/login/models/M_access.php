<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_access extends CI_Model{

	function access($user, $password){
		$this->db->where('email', $user);
		$this->db->where('password', $password);
		$query = $this->db->get('admin');
		if($query->num_rows() > 0){
			$data        = $query->row();
			$record      = array(
				'id_adm'       => $data->id_adm,
				'activity'     => 'login',
				'record'       => date('Y-m-d H:i:s')
				);
			
			$this->db->insert('record_activity', $record);

			return $data;
		}else{
			return NULL;
		}
	}

	function record_activity($data){
		$record      = array(
				'id_adm'       => $data['id_user'],
				'activity'     => $data['activity'],
				'record'       => date('Y-m-d H:i:s')
				);
		$this->db->insert('record_activity', $record);
	}
}