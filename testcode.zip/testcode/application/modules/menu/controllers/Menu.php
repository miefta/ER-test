<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends MY_Controller {

	function __construct(){
    parent::__construct();
	   	$this->load->model('m_menu');
  	}

	public function index(){
		$data['makanan'] = $this->m_menu->daftar_menu('makanan');
		$data['minuman'] = $this->m_menu->daftar_menu('minuman');
		$this->render_page('mainpage', $data);
	}

	public function menuAPI(){
		$data = array();
		foreach ($this->m_menu->daftar_menu()->result() as $key) {
			$data[] = $key;
		}
		echo json_encode($data);
	}

	
}
