<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_menu extends CI_Model{

	function daftar_menu($menu = null){
		if($menu != null){
			$this->db->where('kategori', $menu);
		}
		return $this->db->get('menu');
	}
}