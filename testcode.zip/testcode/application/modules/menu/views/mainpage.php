    <section class="content-header">
      <h1>
        Daftar Menu
        <a href="<?php echo base_url('pesanan/buat_pesanan') ?>" class="pull-right btn btn-success">Buat  Pesanan Baru</a>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="row">
       
      <div class="col-sm-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true">Makanan</a></li>
              <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="false">Minuman</a></li>
              
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                <div class="row">
                <?php 
                foreach ($makanan->result() as $key) {
                ?>
                <div class="col-sm-3">
                <div class="box-produk">
                <div class="img">
                <img class="img-responsive" src="<?php echo base_url('assets/img/').$key->image ?>">
                <?php 
                if($key->status == 'empty'){
                    echo '<div class="sold">HABIS</div>';
                  }
                ?>
                </div>
                <div class="text-center">
                    <p><strong><?php echo $key->nama_menu ?></strong></p>
                    <span><?php echo 'IDR '.rupiah($key->harga) ?></span>
                </div>
                </div>
                </div>
                <?php } ?>
                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
              <div class="row">
                <?php 
                foreach ($minuman->result() as $key) {
                ?>
                <div class="col-sm-3">
                <div class="box-produk">
                <img class="img-responsive" src="<?php echo base_url('assets/img/').$key->image ?>">
                <div class="text-center">
                    <p><strong><?php echo $key->nama_menu ?></strong></p>
                    <span><?php echo 'IDR '.rupiah($key->harga) ?></span>
                </div>
                </div>
                </div>
                <?php } ?>
                </div>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        
      </div>
      <!-- /.row (main row) -->

    </section>