<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_kasir extends CI_Model{

	
}