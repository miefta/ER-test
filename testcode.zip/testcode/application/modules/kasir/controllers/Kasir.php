<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kasir extends MY_Controller {

	function __construct(){
    parent::__construct();
	   	$this->load->model('m_kasir');
  	}

	public function index(){
		$this->render_page('pembayaran');
	}

}
