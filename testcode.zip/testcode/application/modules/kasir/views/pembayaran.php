<section class="content-header">
<h1>Pembayaran
<a href="<?php echo base_url('pesanan') ?>" class="pull-right btn btn-success">Daftar Pesanan</a></h1>
</section>

<section class="content">
    <div class="row">
    <div class="col-sm-12">
    <div class="box box-default">
    <div class="box-body">
    <div class="row">
      <div class="col-sm-4">
          <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                <input type="text" class="form-control" value="" readonly>
            </div>
            </div>
            <div class="col-sm-4">
          <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-list" aria-hidden="true"></i></span>
                <input id="ordernumber" type="text" class="form-control" value="" readonly>
            </div>
            </div>
            <div class="col-sm-4">
          	<div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" value="<?php echo $this->session->userdata('admin_name'); ?>" readonly>
              </div>
            </div>            
        </div>
    </div>
    </div>
    </div>


    <div class="col-sm-6">
    
    </div>

    <div class="col-sm-6">
    
    <form id="form-pemesanan" action="<?php echo base_url('pesanan/prosesorder'); ?>" method="post"> 
    <div class="box box-default">
        <div class="box-header with-border row">
            <div class="col-sm-6 text-right">
                <label style="margin-top: 5px;">No. Meja</label>
            </div>
            <div class="col-sm-6">
                
            </div>
              
              
        </div>
    <div class="box-body  scrollable scr-min">
      <table class="table table-pos">
            <thead>
                <tr>
                    <th>Menu</th>
                    <th>Qty</th>
                    <th class="text-right">Harga</th>
                    <th class="text-right">Total</th>
                </tr>
            </thead>
            <tbody>           
            
            </tbody>
        </table>
    </div>
    

    
    <div class="box-body">
    <div class="transaction-menu">
            <div class="row">
            <div class="col-sm-12 ">
            <div class="bts-pr"></div>
            <table id="total-amount-due">
              <tbody><tr>
                <td>TOTAL AMOUNT</td>
                <td>
                  <input style="font-weight: 600; font-size: 20px" type="text" class="form-control total-amount-due priceformat text-right" value="" readonly="">
                </td>
              </tr>
            </tbody></table>
            </div>
        </div>
        </div>
    </div>
    </div>

    <ul class="pos-payment">
            <li>
             <button type="submit" class="btn btn-block btn-lg btn-success xxcfgh"><b>Bayar</b></button>
            </li>
            <div class="clearfix"></div>
    </ul>
    </form>

    </div>

    </div>
</section>

