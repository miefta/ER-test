function alert_notifications($type, $messsage){
	if($type != null){
	var notif = '<div class="alert '+$type+' alert-dismissible">'+
    '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'+$messsage+
    '</div>';
    $('.alert_notifications').addClass('show');
	$('.alert_notifications.show').append(notif); 
	}
}